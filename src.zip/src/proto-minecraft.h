#ifndef PROTO_MINECRAFT_H
#define PROTO_MINECRAFT_H
#include "proto-banner1.h"

extern const struct ProtocolParserStream banner_minecraft;

#endif